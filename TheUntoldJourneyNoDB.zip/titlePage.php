<!DOCTYPE html>
<html class="titlePage">
    <head>
        <title>The Untold Journey</title>
        <link href="journeyStyle.css" rel="stylesheet"/>
    </head>
    <body class="titlePage">
        <h1>The Untold Journey</h1>
        <!-- This button directs the user to the directions page. -->
        <a href="directionsPage.php"><button type="button">Click Here to Begin!</button></a>
    </body>
</html>