<!-- This is the index page that the program starts at and then directs the user to the title page.
This is a simple adventure game for grade school kids to help them pratice their math skills. -->
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>The Untold Journey</title>
    </head>

    <body>
        <?php header("Location: titlePage.php"); ?>
    </body>
</html>